'''
Dynamically send an environment specific config
for reactjs webapp on /config/config.json
'''

import json

def lambda_handler(event, context):
	content = {
				'endpoint': 'https://2nktrhesezdf7ayzzckqtlin2e.appsync-api.us-east-1.amazonaws.com/graphql',
				'authenticationType': 'AMAZON_COGNITO_USER_POOLS',
				'clientId': '6uquc4h464lg9rjaut5i24r3ou',
				'region': 'us-east-1',
				'userPoolId': 'us-east-1_5IuVtiA5h'
	}
	response = {
		'status': '200',
		'statusDescription': 'OK',
		'headers': {
			'cache-control': [
				{
					'key': 'Cache-Control',
					'value': 'max-age=100'
				}
			],
			"content-type": [
				{
					'key': 'Content-Type',
					'value': 'application/json'
				}
			]
		},
		'body': json.dumps(content)
	}
	return response